# MyPocket AI – Setup Guide & Documentation

## System Architecture Overview

```
mypocket/
├── index.php          ← Main SPA (Dashboard, Expenses, Analytics, Settings)
├── auth.php           ← Login / Register / Logout
├── api.php            ← JSON REST API (all data operations)
├── php/
│   └── config.php     ← DB connection, session, helpers
├── css/
│   └── style.css      ← Full custom dark-theme stylesheet
├── js/
│   └── app.js         ← All frontend logic (Charts, CRUD, Chatbot)
└── sql/
    └── mypocket.sql   ← Database schema + sample data
```

---

## Database Schema

```
users          ← id, name, email, password (bcrypt), avatar
budgets        ← id, user_id, month, year, amount
expenses       ← id, user_id, date, category, amount, description
chatbot_history← id, user_id, role (user/bot), message
```

**Relationships:**
- `budgets.user_id` → `users.id`
- `expenses.user_id` → `users.id`
- `chatbot_history.user_id` → `users.id`

---

## Tech Stack

| Layer     | Technology                  |
|-----------|-----------------------------|
| Frontend  | HTML5, CSS3, Vanilla JS     |
| Styling   | Custom CSS (no Bootstrap)   |
| Charts    | Chart.js 4.x                |
| Backend   | PHP 8.x (PDO)               |
| Database  | MySQL 8.x                   |
| Fonts     | Google Fonts (Inter)        |

---

## Step-by-Step Setup (XAMPP)

### Step 1 – Install XAMPP
Download from https://www.apachefriends.org  
Supports: Windows, Mac, Linux

### Step 2 – Copy project files
Copy the entire `mypocket/` folder to:
```
C:\xampp\htdocs\mypocket\        ← Windows
/Applications/XAMPP/htdocs/mypocket/  ← Mac
```

### Step 3 – Start XAMPP
Open XAMPP Control Panel → Start **Apache** and **MySQL**

### Step 4 – Create the database
1. Open browser → http://localhost/phpmyadmin
2. Click **"New"** on the left panel
3. Name the database: `mypocket_db` → click **Create**
4. Click the **SQL** tab
5. Paste the contents of `sql/mypocket.sql`
6. Click **Go**

### Step 5 – Configure database credentials
Open `php/config.php` and update if needed:
```php
define('DB_HOST', 'localhost');
define('DB_USER', 'root');     // your MySQL username
define('DB_PASS', '');         // your MySQL password (usually empty for XAMPP)
define('DB_NAME', 'mypocket_db');
```

### Step 6 – Open the app
Visit: **http://localhost/mypocket/auth.php**

**Demo login:**
- Email: `demo@student.com`
- Password: `password`

---

## Features Walkthrough

### Dashboard
- 4 summary cards: Budget, Spent, Remaining, Savings
- Live budget progress bar (turns red at 80%)
- Budget warning alert banner
- Pie chart: spending by category
- Bar chart: daily spending (last 14 days)
- Recent 5 expenses list

### Expenses
- Full expense list with pagination
- Add, Edit, Delete expense
- Category badge with emoji + color
- Month/year filter via topbar

### Analytics
- Full-size pie chart (category distribution)
- Full-size bar chart (daily trend)
- Per-category breakdown cards with mini progress bars

### PocketBot AI (Chatbot)
Rule-based chatbot that reads live expense data:

| Question | Response |
|----------|----------|
| "Where did I spend the most?" | Top category + amount + tip |
| "Is my budget enough?" | % used, remaining, alert if >80% |
| "How much did I spend on food?" | Food total + advice |
| "How can I save money?" | Random saving tips |
| "Show my spending total" | Full category breakdown |
| "Transport / bills / entertainment" | Specific category info |

Chat history is saved to `chatbot_history` table.

### Settings
- Set/update monthly budget
- View profile
- Sign out

---

## Security Features
- Passwords hashed with `bcrypt` (PHP `password_hash`)
- Sessions for authentication (`requireLogin()` guard)
- PDO prepared statements (SQL injection prevention)
- XSS prevention via `htmlspecialchars()` and `clean()`
- CSRF: POST actions require session (server-side check)

---

## AI Chatbot Logic (Rule-Based)

The chatbot in `api.php → chatbotLogic()`:
1. Fetches real-time expense data from DB for current user/month
2. Uses regex pattern matching on user message
3. Returns context-aware responses with actual figures
4. Saves conversation to `chatbot_history`

**Extend it:** Add new `if (preg_match('/keyword/', $msg))` blocks for new topics.

---

## Common Issues

| Problem | Solution |
|---------|----------|
| Blank page | Check PHP error logs in XAMPP |
| DB connection failed | Verify credentials in `config.php` |
| Charts not showing | Ensure internet (Chart.js loads from CDN) |
| Login fails | Run the SQL file again, check demo credentials |
| Session issues | Ensure `session_start()` is first line in config.php |

---

## Presentation Tips

1. **Show dashboard first** – impressive summary cards + charts
2. **Add a live expense** – demonstrate CRUD
3. **Open Analytics** – show visual breakdown
4. **Demo chatbot** – ask "Where did I spend the most?" and "Is my budget enough?"
5. **Mention security** – bcrypt passwords, PDO prepared statements
6. **Mention scalability** – can add Claude AI API, push notifications, multi-currency

---

*Built for college-level academic project. Clean, functional, and impressive.*
