<?php
session_start();

define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'mypocket_db');
define('APP_NAME', 'MyPocket AI');

try {
    $pdo = new PDO(
        "mysql:host=".DB_HOST.";dbname=".DB_NAME.";charset=utf8mb4",
        DB_USER, DB_PASS,
        [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ]
    );
} catch (PDOException $e) {
    http_response_code(500);
    die(json_encode(['error' => 'DB error: ' . $e->getMessage()]));
}

function requireLogin() {
    if (empty($_SESSION['user_id'])) {
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) || !empty($_GET['action'])) {
            http_response_code(401);
            header('Content-Type: application/json');
            die(json_encode(['error' => 'Unauthorized']));
        }
        header('Location: auth.php');
        exit;
    }
}

function jsonResponse($data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json');
    echo json_encode($data);
    exit;
}

function clean(string $str): string {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}

$categories = [
    'Food','Shopping','Online Shopping','Transportation',
    'Savings','Bills','Entertainment','Others'
];

$categoryIcons = [
    'Food'=>'🍔','Shopping'=>'🛍️','Online Shopping'=>'🛒',
    'Transportation'=>'🚌','Savings'=>'💰','Bills'=>'📄',
    'Entertainment'=>'🎮','Others'=>'📦',
];

$categoryColors = [
    'Food'=>'#FF6384','Shopping'=>'#36A2EB','Online Shopping'=>'#FFCE56',
    'Transportation'=>'#4BC0C0','Savings'=>'#9966FF','Bills'=>'#FF9F40',
    'Entertainment'=>'#c084fc','Others'=>'#C9CBCF',
];
