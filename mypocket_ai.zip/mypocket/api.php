<?php
// ─────────────────────────────────────────────
// api.php – REST-style JSON API
// ─────────────────────────────────────────────
require_once __DIR__ . '/php/config.php';
requireLogin();

$userId = (int) $_SESSION['user_id'];
$action = $_GET['action'] ?? '';
$method = $_SERVER['REQUEST_METHOD'];

header('Content-Type: application/json');

switch ($action) {

    // ── GET Dashboard summary ──────────────────
    case 'dashboard':
        $month = (int)($_GET['month'] ?? date('n'));
        $year  = (int)($_GET['year']  ?? date('Y'));

        $stmt = $pdo->prepare("SELECT amount FROM budgets WHERE user_id=? AND month=? AND year=?");
        $stmt->execute([$userId, $month, $year]);
        $budget = (float)($stmt->fetchColumn() ?? 0);

        $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND MONTH(date)=? AND YEAR(date)=? AND category != 'Savings'");
        $stmt->execute([$userId, $month, $year]);
        $totalSpent = (float)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE user_id=? AND MONTH(date)=? AND YEAR(date)=? AND category='Savings'");
        $stmt->execute([$userId, $month, $year]);
        $savings = (float)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT category, COALESCE(SUM(amount),0) as total FROM expenses WHERE user_id=? AND MONTH(date)=? AND YEAR(date)=? GROUP BY category ORDER BY total DESC");
        $stmt->execute([$userId, $month, $year]);
        $byCategory = $stmt->fetchAll();

        $stmt = $pdo->prepare("SELECT date, COALESCE(SUM(amount),0) as total FROM expenses WHERE user_id=? AND date >= DATE_SUB(CURDATE(), INTERVAL 13 DAY) AND category != 'Savings' GROUP BY date ORDER BY date ASC");
        $stmt->execute([$userId]);
        $daily = $stmt->fetchAll();

        $stmt = $pdo->prepare("SELECT * FROM expenses WHERE user_id=? AND MONTH(date)=? AND YEAR(date)=? ORDER BY date DESC, id DESC LIMIT 5");
        $stmt->execute([$userId, $month, $year]);
        $recent = $stmt->fetchAll();

        $remaining = $budget - $totalSpent;
        $pct       = $budget > 0 ? round(($totalSpent / $budget) * 100, 1) : 0;

        jsonResponse([
            'budget'      => $budget,
            'total_spent' => $totalSpent,
            'remaining'   => $remaining,
            'savings'     => $savings,
            'percent'     => $pct,
            'alert'       => $pct >= 80,
            'by_category' => $byCategory,
            'daily'       => $daily,
            'recent'      => $recent,
        ]);
        break;

    // ── GET all expenses ───────────────────────
    case 'expenses':
        $month    = (int)($_GET['month'] ?? date('n'));
        $year     = (int)($_GET['year']  ?? date('Y'));
        $page     = max(1, (int)($_GET['page'] ?? 1));
        $limit    = 15;
        $offset   = ($page - 1) * $limit;

        $where  = "WHERE user_id=? AND MONTH(date)=? AND YEAR(date)=?";
        $params = [$userId, $month, $year];

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM expenses $where");
        $stmt->execute($params);
        $total = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT * FROM expenses $where ORDER BY date DESC, id DESC LIMIT $limit OFFSET $offset");
        $stmt->execute($params);
        $expenses = $stmt->fetchAll();

        jsonResponse(['expenses' => $expenses, 'total' => $total, 'pages' => ceil($total / $limit), 'page' => $page]);
        break;

    // ── GET single expense ─────────────────────
    case 'get_expense':
        $id   = (int)($_GET['id'] ?? 0);
        $stmt = $pdo->prepare("SELECT * FROM expenses WHERE id=? AND user_id=?");
        $stmt->execute([$id, $userId]);
        $expense = $stmt->fetch();
        if (!$expense) jsonResponse(['error' => 'Not found'], 404);
        jsonResponse($expense);
        break;

    // ── POST add expense ───────────────────────
    case 'add_expense':
        $data        = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $date        = $data['date']        ?? date('Y-m-d');
        $category    = $data['category']    ?? '';
        $amount      = (float)($data['amount'] ?? 0);
        $description = clean($data['description'] ?? '');

        if (!$date || !$category || $amount <= 0) jsonResponse(['error' => 'Date, category, and amount are required.'], 422);

        global $categories;
        if (!in_array($category, $categories)) jsonResponse(['error' => 'Invalid category.'], 422);

        $stmt = $pdo->prepare("INSERT INTO expenses (user_id, date, category, amount, description) VALUES (?,?,?,?,?)");
        $stmt->execute([$userId, $date, $category, $amount, $description]);
        jsonResponse(['success' => true, 'id' => $pdo->lastInsertId()]);
        break;

    // ── POST update expense ────────────────────
    case 'update_expense':
        $data        = json_decode(file_get_contents('php://input'), true) ?: $_POST;
        $id          = (int)($data['id'] ?? 0);
        $date        = $data['date']      ?? '';
        $category    = $data['category'] ?? '';
        $amount      = (float)($data['amount'] ?? 0);
        $description = clean($data['description'] ?? '');

        if (!$id || !$date || !$category || $amount <= 0) jsonResponse(['error' => 'All fields required.'], 422);

        $stmt = $pdo->prepare("SELECT id FROM expenses WHERE id=? AND user_id=?");
        $stmt->execute([$id, $userId]);
        if (!$stmt->fetch()) jsonResponse(['error' => 'Not found'], 404);

        $stmt = $pdo->prepare("UPDATE expenses SET date=?, category=?, amount=?, description=? WHERE id=? AND user_id=?");
        $stmt->execute([$date, $category, $amount, $description, $id, $userId]);
        jsonResponse(['success' => true]);
        break;

    // ── DELETE expense ─────────────────────────
    case 'delete_expense':
        $id   = (int)($_GET['id'] ?? 0);
        $stmt = $pdo->prepare("DELETE FROM expenses WHERE id=? AND user_id=?");
        $stmt->execute([$id, $userId]);
        jsonResponse(['success' => (bool)$stmt->rowCount()]);
        break;

    // ── GET / POST budget ──────────────────────
    case 'budget':
        $month = (int)($_GET['month'] ?? date('n'));
        $year  = (int)($_GET['year']  ?? date('Y'));

        if ($method === 'POST') {
            $data   = json_decode(file_get_contents('php://input'), true) ?: $_POST;
            $amount = (float)($data['amount'] ?? 0);
            if ($amount <= 0) jsonResponse(['error' => 'Amount must be > 0'], 422);
            $pdo->prepare("INSERT INTO budgets (user_id, month, year, amount) VALUES (?,?,?,?) ON DUPLICATE KEY UPDATE amount=VALUES(amount)")->execute([$userId, $month, $year, $amount]);
            jsonResponse(['success' => true]);
        } else {
            $stmt = $pdo->prepare("SELECT amount FROM budgets WHERE user_id=? AND month=? AND year=?");
            $stmt->execute([$userId, $month, $year]);
            jsonResponse(['budget' => (float)($stmt->fetchColumn() ?? 0)]);
        }
        break;

    // ── POST chatbot (rule-based + Melayu) ────
    case 'chatbot':
        if ($method !== 'POST') jsonResponse(['error' => 'POST only'], 405);
        $data    = json_decode(file_get_contents('php://input'), true);
        $userMsg = trim($data['message'] ?? '');
        $month   = (int)($_GET['month'] ?? date('n'));
        $year    = (int)($_GET['year']  ?? date('Y'));

        if (!$userMsg) jsonResponse(['error' => 'Empty message'], 422);

        // Fetch context
        $stmt = $pdo->prepare("SELECT category, COALESCE(SUM(amount),0) as total FROM expenses WHERE user_id=? AND MONTH(date)=? AND YEAR(date)=? GROUP BY category ORDER BY total DESC");
        $stmt->execute([$userId, $month, $year]);
        $catData = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

        $stmt = $pdo->prepare("SELECT amount FROM budgets WHERE user_id=? AND month=? AND year=?");
        $stmt->execute([$userId, $month, $year]);
        $budget = (float)($stmt->fetchColumn() ?? 0);

        $totalSpent = array_sum($catData) - ($catData['Savings'] ?? 0);
        $savings    = $catData['Savings'] ?? 0;
        $topCat     = $catData ? array_key_first($catData) : 'N/A';
        $topAmt     = $catData ? reset($catData) : 0;
        $remaining  = $budget - $totalSpent;
        $pct        = $budget > 0 ? round(($totalSpent / $budget) * 100) : 0;

        $reply = chatbotReply($userMsg, $catData, $budget, $totalSpent, $topCat, $topAmt, $remaining, $pct, $savings);

        $pdo->prepare("INSERT INTO chatbot_history (user_id, role, message) VALUES (?,?,?)")->execute([$userId, 'user', $userMsg]);
        $pdo->prepare("INSERT INTO chatbot_history (user_id, role, message) VALUES (?,?,?)")->execute([$userId, 'bot', $reply]);

        jsonResponse(['reply' => $reply]);
        break;

    // ── GET chat history ───────────────────────
    case 'chat_history':
        $stmt = $pdo->prepare("SELECT role, message, created_at FROM chatbot_history WHERE user_id=? ORDER BY created_at DESC LIMIT 20");
        $stmt->execute([$userId]);
        $history = array_reverse($stmt->fetchAll());
        jsonResponse(['history' => $history]);
        break;

    default:
        jsonResponse(['error' => 'Unknown action'], 400);
}

// ══════════════════════════════════════════════
// PocketBot – Rule-based (EN + BM + Rojak)
// ══════════════════════════════════════════════
function chatbotReply(string $raw, array $cat, float $budget, float $spent, string $topCat, float $topAmt, float $remaining, float $pct, float $savings): string
{
    $msg = mb_strtolower($raw, 'UTF-8');

    $rmFmt = fn(float $n) => 'RM ' . number_format($n, 2);

    // ── Salam / Greeting ──────────────────────
    if (preg_match('/\b(hi|hello|hey|hai|helo|salam|assalam|apa khabar|selamat)\b/', $msg)) {
        return "👋 Hai! Saya PocketBot, pembantu kewangan anda.\n\nBoleh tanya saya:\n• \"Aku dah habis berapa bulan ni?\"\n• \"Bajet aku cukup tak?\"\n• \"Aku belanja paling banyak kat mana?\"\n• \"Macam mana nak jimat duit?\"";
    }

    // ── Paling banyak / Highest spending ──────
    if (preg_match('/paling (banyak|tinggi|mahal)|most|highest|biggest|terbesar|kategori apa|belanja banyak|habis banyak mana|mana paling/', $msg)) {
        if (!$cat) return "📭 Tiada rekod perbelanjaan bulan ini lagi. Mula tambah perbelanjaan anda!";
        $tip = match($topCat) {
            'Food'           => "💡 Cuba bawa bekal sendiri untuk jimat makan!",
            'Shopping'       => "💡 Cuba tunggu sale atau guna voucher sebelum beli.",
            'Online Shopping'=> "💡 Padam app shopping dari phone — kurang godaan!",
            'Entertainment'  => "💡 Cari aktiviti percuma di kampus atau taman awam.",
            'Transportation' => "💡 Guna pas bas pelajar atau kongsi kereta dengan kawan.",
            default          => "💡 Semak semula perbelanjaan {$topCat} anda.",
        };
        return "🏆 Perbelanjaan tertinggi bulan ini: **{$topCat}** sebanyak **{$rmFmt($topAmt)}**.\n\n{$tip}";
    }

    // ── Bajet / Budget check ───────────────────
    if (preg_match('/bajet|budget|cukup|enough|baki|remaining|balance|lebih|oversp|dah abis|habis bajet/', $msg)) {
        if ($budget == 0) return "⚠️ Anda belum tetapkan bajet bulan ini. Pergi ke **Settings** untuk tetapkan bajet!";
        if ($pct >= 100) return "🚨 **Bajet dah melebihi had!**\nAnda dah belanja {$rmFmt($spent)} daripada {$rmFmt($budget)}.\nPerlu jimat ketat sekarang!";
        if ($pct >= 80)  return "⚠️ **Amaran Bajet!**\nAnda dah guna **{$pct}%** bajet bulan ini.\nBaki tinggal **{$rmFmt($remaining)}** je lagi — berhati-hati!";
        return "✅ Bajet anda masih okay!\nDah guna **{$pct}%** ({$rmFmt($spent)} dibelanjakan).\nBaki **{$rmFmt($remaining)}** lagi untuk bulan ini.";
    }

    // ── Simpanan / Savings ─────────────────────
    if (preg_match('/simpan|saving|save|tabung|jimat|duit simpan/', $msg)) {
        $tips = [
            "Bawa bekal ke kelas 3 hari seminggu.",
            "Guna diskaun pelajar setiap kali membeli.",
            "Set had perbelanjaan mingguan dan patuhinya.",
            "Guna kemudahan kampus percuma — gym, library, WiFi.",
            "Beli buku teks terpakai atau pinjam dari perpustakaan.",
            "Unsubscribe mana-mana langganan yang jarang diguna.",
        ];
        $tip  = $tips[array_rand($tips)];
        $base = $savings > 0
            ? "💰 Bagus! Anda dah simpan **{$rmFmt($savings)}** bulan ini. "
            : "📌 Belum ada simpanan bulan ini. Cuba simpan sikit-sikit dulu, RM20 seminggu pun jadilah! ";
        return $base . "\n\n💡 Tips jimat: *{$tip}*";
    }

    // ── Makanan / Food ─────────────────────────
    if (preg_match('/makan|food|lapar|restoran|cafe|kantin|lunch|dinner|breakfast|sarapan|kedai makan|mamak/', $msg)) {
        $amt = $cat['Food'] ?? 0;
        if ($amt == 0) return "🍔 Tiada rekod perbelanjaan makanan bulan ini lagi.";
        return "🍔 Perbelanjaan makanan bulan ini: **{$rmFmt($amt)}**.\n" .
               ($amt > 200 ? "Agak tinggi tu. Cuba masak sendiri atau bawa bekal!" : "Okay lagi tu, teruskan!");
    }

    // ── Transport ──────────────────────────────
    if (preg_match('/transport|bas|bus|grab|ride|minyak|petrol|parking|commute|travel|perjalanan|naik/', $msg)) {
        $amt = $cat['Transportation'] ?? 0;
        return $amt > 0
            ? "🚌 Perbelanjaan transport: **{$rmFmt($amt)}** bulan ini.\n💡 Guna pas bas pelajar atau kongsi ride dengan kawan untuk jimat!"
            : "🚌 Tiada rekod perbelanjaan transport bulan ini.";
    }

    // ── Bil / Bills ────────────────────────────
    if (preg_match('/bil|bill|telefon|phone|internet|wifi|api|air|elektrik|utility|langganan/', $msg)) {
        $amt = $cat['Bills'] ?? 0;
        return $amt > 0
            ? "📄 Perbelanjaan bil bulan ini: **{$rmFmt($amt)}**.\n💡 Semak plan telefon — ada yang lebih murah untuk pelajar!"
            : "📄 Tiada rekod bil bulan ini.";
    }

    // ── Hiburan / Entertainment ────────────────
    if (preg_match('/hiburan|entertainment|wayang|movie|game|netflix|spotify|tiktok|fun|jalan|hangout/', $msg)) {
        $amt = $cat['Entertainment'] ?? 0;
        return $amt > 0
            ? "🎮 Perbelanjaan hiburan: **{$rmFmt($amt)}** bulan ini.\n" . ($amt > 100 ? "Agak banyak tu — cuba cari aktiviti percuma!" : "Okay lagi, good balance!")
            : "🎮 Tiada rekod perbelanjaan hiburan bulan ini.";
    }

    // ── Shopping ───────────────────────────────
    if (preg_match('/shopping|beli|shopee|lazada|online|kedai|mall|baju|kasut|barang/', $msg)) {
        $amt = ($cat['Shopping'] ?? 0) + ($cat['Online Shopping'] ?? 0);
        return $amt > 0
            ? "🛒 Jumlah perbelanjaan shopping: **{$rmFmt($amt)}** bulan ini.\n" . ($amt > 150 ? "💡 Tunggu 24 jam sebelum beli — elak impulsif buying!" : "Terkawal lagi! 👍")
            : "🛒 Tiada rekod perbelanjaan shopping bulan ini.";
    }

    // ── Jumlah total / Summary ─────────────────
    if (preg_match('/jumlah|total|summary|ringkasan|berapa (habis|dah)|dah habis berapa|perbelanjaan bulan|semua/', $msg)) {
        if (!$cat) return "📭 Tiada rekod perbelanjaan bulan ini lagi.";
        $rows = "";
        foreach ($cat as $c => $a) $rows .= "\n• {$c}: {$rmFmt((float)$a)}";
        return "📊 Ringkasan perbelanjaan bulan ini:\n\n**Dibelanjakan:** {$rmFmt($spent)}" .
               ($savings > 0 ? "\n**Simpanan:** {$rmFmt($savings)}" : "") .
               "\n\nMengikut kategori:{$rows}";
    }

    // ── Tips kewangan ──────────────────────────
    if (preg_match('/tip|nasihat|advice|cara|macam mana|camna|bagaimana|nak jimat|kurang/, $msg')) {
        $tips = [
            "📌 Rekod setiap perbelanjaan, walaupun kecil.",
            "📌 Guna kaedah 50/30/20 — 50% keperluan, 30% kehendak, 20% simpanan.",
            "📌 Set had perbelanjaan mingguan dan semak setiap Ahad.",
            "📌 Unsubscribe langganan yang jarang diguna.",
            "📌 Masak sendiri sekurang-kurangnya 3 kali seminggu.",
            "📌 Cari promo pelajar dan tawaran cashback.",
            "📌 Elak beli kopi mahal setiap hari — buat sendiri!",
        ];
        return "💡 Tips pengurusan duit untuk pelajar:\n\n" . implode("\n", $tips);
    }

    // ── Terima kasih / Bye ─────────────────────
    if (preg_match('/terima kasih|thanks|thank you|ok thanks|bye|selamat tinggal|tq|tenkiu/', $msg)) {
        return "😊 Sama-sama! Ingat — setiap ringgit yang disimpan hari ni adalah pelaburan untuk masa depan anda. Semangat! 💪";
    }

    // ── Patut ke beli / Should I buy ──────────
    if (preg_match('/patut ke|should i|worth it|berbaloi|perlu tak|nak beli|beli tak/', $msg)) {
        if ($pct >= 80) return "🤔 Berdasarkan data anda, bajet bulan ini dah {$pct}% digunakan. **Lebih baik tahan dulu** dan tunggu bulan depan!";
        return "🤔 Bajet anda masih ada **{$rmFmt($remaining)}** lagi. Tanya diri sendiri — adakah ini keperluan atau kehendak? Kalau boleh tunggu, tunggu je! 😄";
    }

    // ── Fallback ───────────────────────────────
    return "🤔 Hmm, saya kurang faham soalan tu. Cuba tanya macam ni:\n\n• \"Aku dah habis berapa bulan ni?\"\n• \"Bajet aku cukup tak?\"\n• \"Aku belanja paling banyak kat mana?\"\n• \"Berapa aku habis untuk makan?\"\n• \"Macam mana nak jimat duit?\"";
}
