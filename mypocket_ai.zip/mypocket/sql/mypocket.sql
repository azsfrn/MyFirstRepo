-- ============================================
-- MyPocket AI – Smart Student Expense Tracker
-- Database Schema (MySQL)
-- ============================================

CREATE DATABASE IF NOT EXISTS mypocket_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE mypocket_db;

-- ─────────────────────────────────────────────
-- Table: users
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS users (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    name        VARCHAR(100)        NOT NULL,
    email       VARCHAR(150)        NOT NULL UNIQUE,
    password    VARCHAR(255)        NOT NULL,
    avatar      VARCHAR(10)         DEFAULT '🎓',
    created_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
-- Table: budgets
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS budgets (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT                 NOT NULL,
    month       TINYINT             NOT NULL COMMENT '1–12',
    year        YEAR                NOT NULL,
    amount      DECIMAL(10,2)       NOT NULL DEFAULT 0.00,
    created_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_budget (user_id, month, year),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
-- Table: expenses
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS expenses (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT                 NOT NULL,
    date        DATE                NOT NULL,
    category    ENUM(
                    'Food',
                    'Shopping',
                    'Online Shopping',
                    'Transportation',
                    'Savings',
                    'Bills',
                    'Entertainment',
                    'Others'
                )                   NOT NULL,
    amount      DECIMAL(10,2)       NOT NULL,
    description VARCHAR(255)        DEFAULT NULL,
    created_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP,
    updated_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_date (user_id, date),
    INDEX idx_user_category (user_id, category)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
-- Table: chatbot_history
-- ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS chatbot_history (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    user_id     INT                 NOT NULL,
    role        ENUM('user','bot')  NOT NULL,
    message     TEXT                NOT NULL,
    created_at  TIMESTAMP           DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_user_chat (user_id, created_at)
) ENGINE=InnoDB;

-- ─────────────────────────────────────────────
-- Sample Data (Demo User)
-- ─────────────────────────────────────────────
INSERT INTO users (name, email, password, avatar) VALUES
('Demo Student', 'demo@student.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '🎓');
-- password: password

INSERT INTO budgets (user_id, month, year, amount) VALUES
(1, MONTH(NOW()), YEAR(NOW()), 1500.00);

INSERT INTO expenses (user_id, date, category, amount, description) VALUES
(1, DATE_FORMAT(NOW(), '%Y-%m-01'), 'Food',           12.50, 'Lunch at cafeteria'),
(1, DATE_FORMAT(NOW(), '%Y-%m-02'), 'Transportation',  4.00, 'Bus pass top-up'),
(1, DATE_FORMAT(NOW(), '%Y-%m-03'), 'Food',            8.90, 'Breakfast & coffee'),
(1, DATE_FORMAT(NOW(), '%Y-%m-04'), 'Bills',          55.00, 'Phone bill'),
(1, DATE_FORMAT(NOW(), '%Y-%m-05'), 'Entertainment',  25.00, 'Movie ticket'),
(1, DATE_FORMAT(NOW(), '%Y-%m-06'), 'Shopping',       79.90, 'New notebook & pens'),
(1, DATE_FORMAT(NOW(), '%Y-%m-07'), 'Food',           15.00, 'Dinner with friends'),
(1, DATE_FORMAT(NOW(), '%Y-%m-08'), 'Online Shopping',49.00, 'Shopee – study lamp'),
(1, DATE_FORMAT(NOW(), '%Y-%m-09'), 'Savings',       100.00, 'Monthly savings'),
(1, DATE_FORMAT(NOW(), '%Y-%m-10'), 'Food',           11.50, 'Lunch'),
(1, DATE_FORMAT(NOW(), '%Y-%m-11'), 'Transportation',  4.00, 'Grab ride'),
(1, DATE_FORMAT(NOW(), '%Y-%m-12'), 'Entertainment',  12.00, 'Netflix share'),
(1, DATE_FORMAT(NOW(), '%Y-%m-13'), 'Food',           20.00, 'Weekend brunch'),
(1, DATE_FORMAT(NOW(), '%Y-%m-14'), 'Shopping',       35.00, 'T-shirt sale'),
(1, DATE_FORMAT(NOW(), '%Y-%m-15'), 'Bills',          45.00, 'Internet bill');
