<?php
// ─────────────────────────────────────────────
// auth.php – Login / Register / Logout handler
// ─────────────────────────────────────────────
require_once __DIR__ . '/php/config.php';

$action = $_GET['action'] ?? 'login';
$error  = '';
$success = '';

// ── Handle POST ──────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if ($action === 'login') {
        $email    = clean($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if ($email && $password) {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
            $stmt->execute([$email]);
            $user = $stmt->fetch();

            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id']   = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                $_SESSION['user_avatar'] = $user['avatar'];
                header('Location: index.php');
                exit;
            } else {
                $error = 'Invalid email or password.';
            }
        } else {
            $error = 'Please fill in all fields.';
        }
    }

    if ($action === 'register') {
        $name     = clean($_POST['name'] ?? '');
        $email    = clean($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';
        $confirm  = $_POST['confirm_password'] ?? '';

        if (!$name || !$email || !$password) {
            $error = 'All fields are required.';
        } elseif ($password !== $confirm) {
            $error = 'Passwords do not match.';
        } elseif (strlen($password) < 6) {
            $error = 'Password must be at least 6 characters.';
        } else {
            $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
            $stmt->execute([$email]);
            if ($stmt->fetch()) {
                $error = 'Email already registered.';
            } else {
                $hashed = password_hash($password, PASSWORD_BCRYPT);
                $stmt   = $pdo->prepare("INSERT INTO users (name, email, password) VALUES (?, ?, ?)");
                $stmt->execute([$name, $email, $hashed]);
                $userId = $pdo->lastInsertId();

                // Create default budget for current month
                $pdo->prepare("INSERT INTO budgets (user_id, month, year, amount) VALUES (?, ?, ?, 1000)")
                    ->execute([$userId, date('n'), date('Y')]);

                $success = 'Account created! You can now log in.';
                $action  = 'login';
            }
        }
    }
}

if ($action === 'logout') {
    session_destroy();
    header('Location: auth.php?action=login');
    exit;
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MyPocket AI – <?= $action === 'login' ? 'Sign In' : 'Sign Up' ?></title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<style>
  :root {
    --primary: #6C5CE7;
    --primary-light: #a29bfe;
    --accent: #00CEC9;
    --dark: #0f0f1a;
    --card-bg: #1a1a2e;
    --text-muted: #8888aa;
  }
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: 'Inter', sans-serif;
    background: var(--dark);
    min-height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    background-image: radial-gradient(ellipse at 20% 50%, rgba(108,92,231,0.15) 0%, transparent 50%),
                      radial-gradient(ellipse at 80% 20%, rgba(0,206,201,0.10) 0%, transparent 40%);
  }
  .auth-card {
    background: var(--card-bg);
    border: 1px solid rgba(108,92,231,0.3);
    border-radius: 20px;
    padding: 2.5rem;
    width: 100%;
    max-width: 420px;
    box-shadow: 0 25px 60px rgba(0,0,0,0.5);
  }
  .logo { font-size: 2rem; text-align: center; margin-bottom: 0.3rem; }
  .app-title {
    text-align: center;
    font-size: 1.4rem;
    font-weight: 700;
    color: #fff;
    margin-bottom: 0.2rem;
  }
  .app-subtitle {
    text-align: center;
    color: var(--text-muted);
    font-size: 0.85rem;
    margin-bottom: 2rem;
  }
  .form-label { color: #ccc; font-size: 0.85rem; font-weight: 500; }
  .form-control {
    background: rgba(255,255,255,0.05);
    border: 1px solid rgba(255,255,255,0.1);
    color: #fff;
    border-radius: 10px;
    padding: 0.7rem 1rem;
  }
  .form-control:focus {
    background: rgba(108,92,231,0.1);
    border-color: var(--primary);
    color: #fff;
    box-shadow: 0 0 0 3px rgba(108,92,231,0.2);
  }
  .btn-primary {
    background: linear-gradient(135deg, var(--primary), var(--accent));
    border: none;
    border-radius: 10px;
    padding: 0.75rem;
    font-weight: 600;
    font-size: 0.95rem;
    width: 100%;
    letter-spacing: 0.5px;
  }
  .btn-primary:hover { opacity: 0.9; transform: translateY(-1px); }
  .switch-link {
    text-align: center;
    margin-top: 1.5rem;
    color: var(--text-muted);
    font-size: 0.88rem;
  }
  .switch-link a { color: var(--primary-light); text-decoration: none; font-weight: 600; }
  .demo-box {
    background: rgba(108,92,231,0.1);
    border: 1px solid rgba(108,92,231,0.3);
    border-radius: 10px;
    padding: 0.75rem 1rem;
    margin-bottom: 1.5rem;
    font-size: 0.82rem;
    color: var(--primary-light);
  }
  .demo-box strong { color: #fff; }
  .alert { border-radius: 10px; font-size: 0.88rem; }
  .divider { border-top: 1px solid rgba(255,255,255,0.08); margin: 1.5rem 0; }
</style>
</head>
<body>
<div class="auth-card">
  <div class="logo">💸</div>
  <div class="app-title">MyPocket AI</div>
  <div class="app-subtitle">Smart Student Expense Tracker</div>

  <?php if ($error): ?>
    <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
  <?php endif; ?>
  <?php if ($success): ?>
    <div class="alert alert-success"><?= htmlspecialchars($success) ?></div>
  <?php endif; ?>

  <?php if ($action === 'login'): ?>
    <div class="demo-box">
      🎓 <strong>Demo Account:</strong><br>
      Email: <strong>demo@student.com</strong> | Password: <strong>password</strong>
    </div>

    <form method="POST" action="auth.php?action=login">
      <div class="mb-3">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="you@university.edu" required>
      </div>
      <div class="mb-4">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="••••••••" required>
      </div>
      <button type="submit" class="btn btn-primary">Sign In →</button>
    </form>
    <div class="switch-link">
      Don't have an account? <a href="auth.php?action=register">Create one</a>
    </div>

  <?php else: ?>
    <form method="POST" action="auth.php?action=register">
      <div class="mb-3">
        <label class="form-label">Full Name</label>
        <input type="text" name="name" class="form-control" placeholder="Ahmad Faris" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Email Address</label>
        <input type="email" name="email" class="form-control" placeholder="you@university.edu" required>
      </div>
      <div class="mb-3">
        <label class="form-label">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Min. 6 characters" required>
      </div>
      <div class="mb-4">
        <label class="form-label">Confirm Password</label>
        <input type="password" name="confirm_password" class="form-control" placeholder="Repeat password" required>
      </div>
      <button type="submit" class="btn btn-primary">Create Account →</button>
    </form>
    <div class="switch-link">
      Already have an account? <a href="auth.php?action=login">Sign in</a>
    </div>
  <?php endif; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
