'use strict';

// ── State ──────────────────────────────────────────
const state = {
  page:        'dashboard',
  month:       new Date().getMonth() + 1,
  year:        new Date().getFullYear(),
  editingId:   null,
  currentPage: 1,
  charts:      {},
};

const CAT_COLORS = {
  'Food':'#FF6384','Shopping':'#36A2EB','Online Shopping':'#FFCE56',
  'Transportation':'#4BC0C0','Savings':'#9966FF','Bills':'#FF9F40',
  'Entertainment':'#c084fc','Others':'#C9CBCF',
};
const CAT_ICONS = {
  'Food':'🍔','Shopping':'🛍️','Online Shopping':'🛒','Transportation':'🚌',
  'Savings':'💰','Bills':'📄','Entertainment':'🎮','Others':'📦',
};

// ── Init ───────────────────────────────────────────
document.addEventListener('DOMContentLoaded', function() {

  // Wire up Add Expense button
  var btnAdd = document.getElementById('btnAddExpense');
  if (btnAdd) btnAdd.addEventListener('click', openAddModal);

  // Wire up Save button inside modal
  var btnSave = document.getElementById('btnSaveExpense');
  if (btnSave) btnSave.addEventListener('click', saveExpense);

  // Wire up Cancel button
  var btnCancel = document.getElementById('btnCancelModal');
  if (btnCancel) btnCancel.addEventListener('click', function() { toggleModal(false); });

  // Close modal when clicking backdrop
  var modal = document.getElementById('expenseModal');
  if (modal) modal.addEventListener('click', function(e) {
    if (e.target === modal) toggleModal(false);
  });

  // Chat enter key
  var chatInput = document.getElementById('chatInput');
  if (chatInput) chatInput.addEventListener('keydown', function(e) {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendChat(); }
  });

  navigateTo('dashboard');
});

// ── Navigation ─────────────────────────────────────
function navigateTo(page) {
  state.page = page;

  document.querySelectorAll('.page').forEach(function(p) { p.classList.remove('active'); });
  document.querySelectorAll('.nav-item').forEach(function(n) { n.classList.remove('active'); });

  var pageEl = document.getElementById('page-' + page);
  if (pageEl) pageEl.classList.add('active');

  var navEl = document.querySelector('[data-page="' + page + '"]');
  if (navEl) navEl.classList.add('active');

  var titles = {
    dashboard: ['📊 Dashboard',       'Snapshot bulanan anda'],
    expenses:  ['💳 Perbelanjaan',     'Rekod setiap ringgit'],
    analytics: ['📈 Analitik',         'Analisis perbelanjaan'],
    chatbot:   ['🤖 PocketBot AI',     'Pembantu pintar anda'],
    settings:  ['⚙️ Tetapan',          'Bajet & akaun'],
  };
  var t = titles[page] || ['MyPocket AI',''];
  setText('topbarTitle', t[0]);
  setText('topbarSub',   t[1]);

  document.querySelector('.sidebar') && document.querySelector('.sidebar').classList.remove('open');

  if (page === 'dashboard') loadDashboard();
  if (page === 'expenses')  loadExpenses();
  if (page === 'analytics') loadAnalytics();
  if (page === 'chatbot')   loadChatHistory();
  if (page === 'settings')  loadSettings();
}

function onPeriodChange() {
  state.month = parseInt(document.getElementById('monthSel').value);
  state.year  = parseInt(document.getElementById('yearSel').value);
  state.currentPage = 1;
  if (state.page === 'dashboard') loadDashboard();
  if (state.page === 'expenses')  loadExpenses();
  if (state.page === 'analytics') loadAnalytics();
}

function toggleSidebar() {
  var s = document.querySelector('.sidebar');
  if (s) s.classList.toggle('open');
}

// ── API ────────────────────────────────────────────
function api(action, opts) {
  opts = opts || {};
  var url    = 'api.php?action=' + action + '&month=' + state.month + '&year=' + state.year;
  var method = opts.method || 'GET';
  var fetchOpts = { method: method };
  if (method === 'POST') {
    fetchOpts.headers = { 'Content-Type': 'application/json' };
    if (opts.body) fetchOpts.body = JSON.stringify(opts.body);
  }
  return fetch(url, fetchOpts)
    .then(function(r) { return r.json(); })
    .catch(function(e) { console.error('API error:', e); return { error: 'Connection error' }; });
}

// ── Dashboard ──────────────────────────────────────
function loadDashboard() {
  api('dashboard').then(function(data) {
    if (data.error) { toast('Gagal load dashboard', 'error'); return; }

    setText('budgetVal',    'RM ' + fmt(data.budget));
    setText('spentVal',     'RM ' + fmt(data.total_spent));
    setText('remainingVal', 'RM ' + fmt(data.remaining));
    setText('savingsVal',   'RM ' + fmt(data.savings));

    var pct  = Math.min(parseFloat(data.percent) || 0, 100);
    var fill = document.getElementById('budgetFill');
    if (fill) {
      fill.style.width = pct + '%';
      fill.className   = 'budget-bar-fill' + (pct >= 80 ? ' warn' : '');
    }
    setText('budgetPct', (data.percent || 0) + '% bajet digunakan');

    var alertEl = document.getElementById('budgetAlert');
    if (alertEl) alertEl.classList.toggle('visible', !!data.alert);

    renderRecentExpenses(data.recent || []);
    renderPieChart('pieChartMini', data.by_category || []);
    renderBarChart('barChartMini', data.daily || []);
  });
}

function renderRecentExpenses(expenses) {
  var el = document.getElementById('recentExpenses');
  if (!el) return;
  if (!expenses.length) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">📭</div><p>Tiada perbelanjaan bulan ini.</p></div>';
    return;
  }
  el.innerHTML = expenses.map(function(e) {
    return '<div style="display:flex;align-items:center;gap:.75rem;padding:.6rem 0;border-bottom:1px solid rgba(255,255,255,.04)">'
      + '<span style="font-size:1.2rem">' + (CAT_ICONS[e.category] || '📦') + '</span>'
      + '<div style="flex:1;min-width:0">'
      + '<div style="font-size:.85rem;font-weight:500;color:#ddd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">'
      + esc(e.category) + (e.description ? ' – ' + esc(e.description) : '') + '</div>'
      + '<div style="font-size:.75rem;color:var(--text-muted)">' + formatDate(e.date) + '</div>'
      + '</div>'
      + '<div style="font-weight:700;color:#fff;font-size:.9rem">RM ' + fmt(e.amount) + '</div>'
      + '</div>';
  }).join('');
}

// ── Expenses ───────────────────────────────────────
function loadExpenses(page) {
  page = page || 1;
  state.currentPage = page;
  api('expenses&page=' + page).then(function(data) {
    if (data.error) { toast('Gagal load perbelanjaan', 'error'); return; }
    renderExpenseTable(data.expenses || []);
    renderPagination(data.page, data.pages);
  });
}

function renderExpenseTable(expenses) {
  var tbody = document.getElementById('expenseTableBody');
  if (!tbody) return;
  if (!expenses.length) {
    tbody.innerHTML = '<tr><td colspan="5" style="padding:2.5rem;text-align:center">'
      + '<div class="empty-state"><div class="empty-icon">📋</div>'
      + '<h4>Tiada rekod perbelanjaan</h4>'
      + '<p>Klik "Tambah Perbelanjaan" untuk mula.</p></div></td></tr>';
    return;
  }
  tbody.innerHTML = expenses.map(function(e) {
    return '<tr>'
      + '<td class="date-cell">' + formatDate(e.date) + '</td>'
      + '<td><span class="category-badge" style="color:' + (CAT_COLORS[e.category] || '#aaa') + '">'
      + (CAT_ICONS[e.category] || '📦') + ' ' + esc(e.category) + '</span></td>'
      + '<td class="amount-cell">RM ' + fmt(e.amount) + '</td>'
      + '<td class="desc-cell">' + esc(e.description || '—') + '</td>'
      + '<td>'
      + '<button class="btn-action btn-edit" data-id="' + e.id + '" title="Edit">✏️</button>'
      + '<button class="btn-action btn-delete" data-id="' + e.id + '" title="Padam">🗑️</button>'
      + '</td>'
      + '</tr>';
  }).join('');

  // Wire edit/delete after render
  document.querySelectorAll('.btn-edit').forEach(function(btn) {
    btn.addEventListener('click', function() { openEditModal(parseInt(this.dataset.id)); });
  });
  document.querySelectorAll('.btn-delete').forEach(function(btn) {
    btn.addEventListener('click', function() { deleteExpense(parseInt(this.dataset.id)); });
  });
}

function renderPagination(current, total) {
  var el = document.getElementById('pagination');
  if (!el) return;
  if (!total || total <= 1) { el.innerHTML = ''; return; }
  var html = '';
  for (var i = 1; i <= total; i++) {
    html += '<button class="page-btn' + (i === current ? ' active' : '') + '" data-pg="' + i + '">' + i + '</button>';
  }
  el.innerHTML = html;
  el.querySelectorAll('.page-btn').forEach(function(btn) {
    btn.addEventListener('click', function() { loadExpenses(parseInt(this.dataset.pg)); });
  });
}

// ── Modal ──────────────────────────────────────────
function openAddModal() {
  state.editingId = null;
  setText('modalTitle', '➕ Tambah Perbelanjaan');
  document.getElementById('expenseDate').value     = new Date().toISOString().split('T')[0];
  document.getElementById('expenseCategory').value = '';
  document.getElementById('expenseAmount').value   = '';
  document.getElementById('expenseDesc').value     = '';
  toggleModal(true);
}

function openEditModal(id) {
  state.editingId = id;
  api('get_expense&id=' + id).then(function(data) {
    if (data.error) { toast('Rekod tidak dijumpai', 'error'); return; }
    setText('modalTitle', '✏️ Edit Perbelanjaan');
    document.getElementById('expenseDate').value     = data.date;
    document.getElementById('expenseCategory').value = data.category;
    document.getElementById('expenseAmount').value   = data.amount;
    document.getElementById('expenseDesc').value     = data.description || '';
    toggleModal(true);
  });
}

function toggleModal(open) {
  var m = document.getElementById('expenseModal');
  if (m) m.classList.toggle('open', open);
}

function saveExpense() {
  var date     = document.getElementById('expenseDate').value;
  var category = document.getElementById('expenseCategory').value;
  var amount   = parseFloat(document.getElementById('expenseAmount').value);
  var desc     = document.getElementById('expenseDesc').value;

  if (!date)              { toast('Sila pilih tarikh.', 'error'); return; }
  if (!category)          { toast('Sila pilih kategori.', 'error'); return; }
  if (!amount || amount <= 0) { toast('Sila masukkan jumlah yang sah.', 'error'); return; }

  var action = state.editingId ? 'update_expense' : 'add_expense';
  var body   = { date: date, category: category, amount: amount, description: desc };
  if (state.editingId) body.id = state.editingId;

  var btnSave = document.getElementById('btnSaveExpense');
  if (btnSave) { btnSave.disabled = true; btnSave.textContent = 'Menyimpan…'; }

  api(action, { method: 'POST', body: body }).then(function(res) {
    if (btnSave) { btnSave.disabled = false; btnSave.textContent = '💾 Simpan'; }
    if (res.success) {
      toggleModal(false);
      toast(state.editingId ? '✅ Perbelanjaan dikemaskini!' : '✅ Perbelanjaan ditambah!', 'success');
      loadExpenses(state.currentPage);
      if (state.page === 'dashboard') loadDashboard();
    } else {
      toast(res.error || 'Sesuatu tidak kena. Cuba lagi.', 'error');
    }
  });
}

function deleteExpense(id) {
  if (!confirm('Padam perbelanjaan ini?')) return;
  api('delete_expense&id=' + id).then(function(res) {
    if (res.success) {
      toast('🗑️ Perbelanjaan dipadam.', 'success');
      loadExpenses(state.currentPage);
      if (state.page === 'dashboard') loadDashboard();
    } else {
      toast('Gagal padam. Cuba lagi.', 'error');
    }
  });
}

// ── Analytics ──────────────────────────────────────
function loadAnalytics() {
  api('dashboard').then(function(data) {
    if (data.error) return;
    renderPieChart('pieChartFull', data.by_category || []);
    renderBarChart('barChartFull', data.daily || []);
    renderCategoryCards(data.by_category || []);
  });
}

function renderCategoryCards(byCategory) {
  var el = document.getElementById('categoryCards');
  if (!el) return;
  if (!byCategory.length) {
    el.innerHTML = '<p style="color:var(--text-muted);text-align:center;padding:1rem">Tiada data untuk tempoh ini.</p>';
    return;
  }
  var total = byCategory.reduce(function(s, c) { return s + parseFloat(c.total); }, 0);
  el.innerHTML = byCategory.map(function(c) {
    var pct = total > 0 ? ((c.total / total) * 100).toFixed(1) : 0;
    return '<div class="card" style="display:flex;align-items:center;gap:.75rem;padding:.9rem 1rem">'
      + '<span style="font-size:1.5rem">' + (CAT_ICONS[c.category] || '📦') + '</span>'
      + '<div style="flex:1">'
      + '<div style="font-size:.85rem;font-weight:600;color:#ddd">' + esc(c.category) + '</div>'
      + '<div style="font-size:.75rem;color:var(--text-muted)">' + pct + '% daripada jumlah</div>'
      + '<div style="height:4px;background:rgba(255,255,255,.07);border-radius:2px;margin-top:.35rem">'
      + '<div style="height:100%;width:' + pct + '%;background:' + (CAT_COLORS[c.category] || '#aaa') + ';border-radius:2px"></div>'
      + '</div></div>'
      + '<div style="font-weight:700;color:#fff;font-size:.95rem;min-width:80px;text-align:right">RM ' + fmt(c.total) + '</div>'
      + '</div>';
  }).join('');
}

// ── Charts ─────────────────────────────────────────
function renderPieChart(id, data) {
  var canvas = document.getElementById(id);
  if (!canvas) return;
  if (state.charts[id]) { state.charts[id].destroy(); delete state.charts[id]; }
  if (!data.length) return;
  state.charts[id] = new Chart(canvas, {
    type: 'doughnut',
    data: {
      labels: data.map(function(c){ return c.category; }),
      datasets: [{
        data:            data.map(function(c){ return parseFloat(c.total); }),
        backgroundColor: data.map(function(c){ return CAT_COLORS[c.category] || '#aaa'; }),
        borderWidth: 2, borderColor: '#16162a', hoverOffset: 6,
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { position:'bottom', labels:{ color:'#8888aa', font:{size:11}, boxWidth:12, padding:10 }},
        tooltip: { callbacks: { label: function(ctx){ return ' RM ' + fmt(ctx.parsed); }}},
      },
      cutout: '62%',
    },
  });
}

function renderBarChart(id, daily) {
  var canvas = document.getElementById(id);
  if (!canvas) return;
  if (state.charts[id]) { state.charts[id].destroy(); delete state.charts[id]; }
  if (!daily.length) return;
  state.charts[id] = new Chart(canvas, {
    type: 'bar',
    data: {
      labels: daily.map(function(d){ return formatDateShort(d.date); }),
      datasets: [{
        label: 'Harian (RM)',
        data:  daily.map(function(d){ return parseFloat(d.total); }),
        backgroundColor: 'rgba(108,92,231,.6)',
        borderColor:     'rgba(108,92,231,1)',
        borderWidth: 1.5, borderRadius: 4,
        hoverBackgroundColor: 'rgba(0,206,201,.7)',
      }],
    },
    options: {
      responsive: true, maintainAspectRatio: false,
      plugins: {
        legend: { display: false },
        tooltip: { callbacks: { label: function(ctx){ return ' RM ' + fmt(ctx.parsed.y); }}},
      },
      scales: {
        x: { ticks:{ color:'#8888aa', font:{size:10} }, grid:{ color:'rgba(255,255,255,.04)' }},
        y: { ticks:{ color:'#8888aa', font:{size:10}, callback: function(v){ return 'RM'+v; }}, grid:{ color:'rgba(255,255,255,.06)' }, beginAtZero:true },
      },
    },
  });
}

// ── Settings / Budget ──────────────────────────────
function loadSettings() {
  api('budget').then(function(data) {
    var el = document.getElementById('budgetInput');
    if (el && data.budget) el.value = data.budget;
  });
}

function saveBudget() {
  var amount = parseFloat(document.getElementById('budgetInput').value);
  if (!amount || amount <= 0) { toast('Masukkan jumlah bajet yang sah.', 'error'); return; }
  api('budget', { method:'POST', body:{ amount: amount }}).then(function(res) {
    if (res.success) {
      toast('✅ Bajet disimpan!', 'success');
      if (state.page === 'dashboard') loadDashboard();
    } else {
      toast(res.error || 'Gagal simpan bajet.', 'error');
    }
  });
}

// ── Chatbot ────────────────────────────────────────
function loadChatHistory() {
  api('chat_history').then(function(data) {
    var container = document.getElementById('chatMessages');
    if (!container) return;
    container.innerHTML = '';
    var msgs = data.history || [];
    if (!msgs.length) {
      appendMsg('bot', '👋 Hai! Saya PocketBot, pembantu kewangan anda.\n\nCuba tanya saya:\n• "Aku dah habis berapa bulan ni?"\n• "Bajet aku cukup tak?"\n• "Aku belanja paling banyak kat mana?"\n• "Macam mana nak jimat duit?"');
    } else {
      msgs.forEach(function(m) { appendMsg(m.role, m.message); });
    }
  });
}

function appendMsg(role, text) {
  var container = document.getElementById('chatMessages');
  if (!container) return;
  var div = document.createElement('div');
  div.className = 'chat-msg ' + role;
  var formatted = esc(text)
    .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
    .replace(/\n/g, '<br>');
  div.innerHTML = '<div class="chat-avatar">' + (role==='bot'?'🤖':'👤') + '</div>'
    + '<div class="chat-bubble">' + formatted + '</div>';
  container.appendChild(div);
  container.scrollTop = container.scrollHeight;
}

function sendChat(prefill) {
  var input = document.getElementById('chatInput');
  var msg   = (prefill || (input && input.value) || '').trim();
  if (!msg) return;
  if (input) input.value = '';

  appendMsg('user', msg);

  // Typing indicator
  var c   = document.getElementById('chatMessages');
  var dot = document.createElement('div');
  dot.className = 'chat-msg bot'; dot.id = 'typingDot';
  dot.innerHTML = '<div class="chat-avatar">🤖</div><div class="chat-bubble">'
    + '<span class="typing-dot"></span><span class="typing-dot"></span><span class="typing-dot"></span>'
    + '</div>';
  if (c) { c.appendChild(dot); c.scrollTop = c.scrollHeight; }

  api('chatbot', { method:'POST', body:{ message: msg }}).then(function(res) {
    var d = document.getElementById('typingDot');
    if (d) d.remove();
    appendMsg('bot', res.reply || 'Maaf, cuba lagi.');
  });
}

// ── Helpers ────────────────────────────────────────
function fmt(n) {
  return parseFloat(n || 0).toLocaleString('en-MY', { minimumFractionDigits:2, maximumFractionDigits:2 });
}
function setText(id, text) {
  var el = document.getElementById(id);
  if (el) el.textContent = text;
}
function formatDate(s) {
  return new Date(s + 'T00:00:00').toLocaleDateString('en-MY', { day:'2-digit', month:'short', year:'numeric' });
}
function formatDateShort(s) {
  return new Date(s + 'T00:00:00').toLocaleDateString('en-MY', { day:'2-digit', month:'short' });
}
function esc(s) {
  return String(s || '').replace(/[&<>"']/g, function(m) {
    return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m];
  });
}
function toast(msg, type) {
  type = type || 'success';
  var c = document.getElementById('toastContainer');
  if (!c) return;
  var d = document.createElement('div');
  d.className = 'toast ' + type;
  d.innerHTML = '<span>' + (type==='success'?'✅':'❌') + '</span> ' + esc(msg);
  c.appendChild(d);
  setTimeout(function() { d.remove(); }, 3500);
}
