<?php
require_once __DIR__ . '/php/config.php';
requireLogin();

$userName   = htmlspecialchars($_SESSION['user_name'] ?? 'Pelajar');
$userAvatar = htmlspecialchars($_SESSION['user_avatar'] ?? '🎓');
$months = ['Jan','Feb','Mac','Apr','Mei','Jun','Jul','Ogo','Sep','Okt','Nov','Dis'];
$curMonth = (int)date('n');
$curYear  = (int)date('Y');
?>
<!DOCTYPE html>
<html lang="ms">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>MyPocket AI</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="css/style.css">
</head>
<body>

<!-- SIDEBAR -->
<nav class="sidebar" id="sidebar">
  <div class="sidebar-logo">
    <span class="logo-icon">💸</span>
    <div>
      <div class="logo-text">MyPocket AI</div>
      <span class="logo-sub">Smart Expense Tracker</span>
    </div>
  </div>
  <div class="sidebar-nav">
    <div class="nav-section-title">Menu</div>
    <a class="nav-item" data-page="dashboard" onclick="navigateTo('dashboard')">
      <span class="nav-icon">📊</span> Dashboard
    </a>
    <a class="nav-item" data-page="expenses" onclick="navigateTo('expenses')">
      <span class="nav-icon">💳</span> Perbelanjaan
    </a>
    <a class="nav-item" data-page="analytics" onclick="navigateTo('analytics')">
      <span class="nav-icon">📈</span> Analitik
    </a>
    <div class="nav-section-title" style="margin-top:1rem">AI</div>
    <a class="nav-item" data-page="chatbot" onclick="navigateTo('chatbot')">
      <span class="nav-icon">🤖</span> PocketBot AI
    </a>
    <div class="nav-section-title" style="margin-top:1rem">Akaun</div>
    <a class="nav-item" data-page="settings" onclick="navigateTo('settings')">
      <span class="nav-icon">⚙️</span> Tetapan
    </a>
  </div>
  <div class="sidebar-user">
    <div class="user-avatar"><?= $userAvatar ?></div>
    <div>
      <div class="user-name"><?= $userName ?></div>
      <div class="user-role">Pelajar</div>
    </div>
    <button class="logout-btn" onclick="location.href='auth.php?action=logout'" title="Log Keluar">🚪</button>
  </div>
</nav>

<!-- MAIN -->
<div class="main-content">

  <!-- Topbar -->
  <div class="topbar">
    <button class="menu-toggle" onclick="toggleSidebar()">☰</button>
    <div style="flex:1">
      <div class="topbar-title" id="topbarTitle">📊 Dashboard</div>
      <div class="topbar-subtitle" id="topbarSub">Snapshot bulanan anda</div>
    </div>
    <div class="month-selector">
      📅
      <select id="monthSel" onchange="onPeriodChange()">
        <?php foreach ($months as $i => $m): ?>
          <option value="<?= $i+1 ?>" <?= ($i+1)==$curMonth?'selected':'' ?>><?= $m ?></option>
        <?php endforeach; ?>
      </select>
      <select id="yearSel" onchange="onPeriodChange()">
        <?php for($y=$curYear; $y>=$curYear-3; $y--): ?>
          <option value="<?= $y ?>" <?= $y==$curYear?'selected':'' ?>><?= $y ?></option>
        <?php endfor; ?>
      </select>
    </div>
  </div>

  <!-- ═══ DASHBOARD ═══ -->
  <div class="page active" id="page-dashboard">
    <div class="budget-alert" id="budgetAlert">
      ⚠️ <strong>Amaran Bajet!</strong>&nbsp; Anda dah guna 80%+ bajet bulan ini. Berhati-hati!
    </div>
    <div class="summary-grid">
      <div class="summary-card budget">
        <span class="card-icon">🎯</span>
        <div class="card-label">Bajet Bulanan</div>
        <div class="card-value" id="budgetVal">RM 0.00</div>
        <div class="budget-bar-wrap">
          <div class="budget-bar"><div class="budget-bar-fill" id="budgetFill" style="width:0%"></div></div>
          <div class="card-sub" id="budgetPct" style="margin-top:4px">0% digunakan</div>
        </div>
      </div>
      <div class="summary-card spent">
        <span class="card-icon">💸</span>
        <div class="card-label">Jumlah Dibelanjakan</div>
        <div class="card-value" id="spentVal">RM 0.00</div>
        <div class="card-sub">Bulan ini</div>
      </div>
      <div class="summary-card remaining">
        <span class="card-icon">💵</span>
        <div class="card-label">Baki</div>
        <div class="card-value" id="remainingVal">RM 0.00</div>
        <div class="card-sub">Baki tersedia</div>
      </div>
      <div class="summary-card savings">
        <span class="card-icon">🏦</span>
        <div class="card-label">Simpanan</div>
        <div class="card-value" id="savingsVal">RM 0.00</div>
        <div class="card-sub">Teruskan! 💪</div>
      </div>
    </div>
    <div class="charts-grid">
      <div class="chart-card">
        <div class="chart-title">🥧 Perbelanjaan Mengikut Kategori</div>
        <div style="height:220px;position:relative"><canvas id="pieChartMini"></canvas></div>
      </div>
      <div class="chart-card">
        <div class="chart-title">📅 Perbelanjaan Harian (14 Hari)</div>
        <div style="height:220px;position:relative"><canvas id="barChartMini"></canvas></div>
      </div>
    </div>
    <div class="card">
      <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:1rem">
        <div class="chart-title" style="margin:0">🕐 Perbelanjaan Terkini</div>
        <button class="btn-outline" onclick="navigateTo('expenses')" style="font-size:.78rem;padding:.35rem .8rem">Lihat Semua →</button>
      </div>
      <div id="recentExpenses"></div>
    </div>
  </div>

  <!-- ═══ EXPENSES ═══ -->
  <div class="page" id="page-expenses">
    <div class="page-header">
      <div class="page-title">Semua <span>Perbelanjaan</span></div>
      <button class="btn-primary-custom" id="btnAddExpense">➕ Tambah Perbelanjaan</button>
    </div>
    <div class="card" style="overflow-x:auto">
      <table class="expense-table">
        <thead>
          <tr>
            <th>Tarikh</th><th>Kategori</th><th>Jumlah</th><th>Keterangan</th><th>Tindakan</th>
          </tr>
        </thead>
        <tbody id="expenseTableBody">
          <tr><td colspan="5" style="text-align:center;padding:2rem;color:var(--text-muted)">Memuatkan…</td></tr>
        </tbody>
      </table>
    </div>
    <div class="pagination" id="pagination"></div>
  </div>

  <!-- ═══ ANALYTICS ═══ -->
  <div class="page" id="page-analytics">
    <div class="page-title" style="margin-bottom:1.25rem">Analisis <span>Perbelanjaan</span></div>
    <div class="charts-grid" style="margin-bottom:1.5rem">
      <div class="chart-card">
        <div class="chart-title">🥧 Agihan Kategori</div>
        <div style="height:280px;position:relative"><canvas id="pieChartFull"></canvas></div>
      </div>
      <div class="chart-card">
        <div class="chart-title">📅 Trend Harian</div>
        <div style="height:280px;position:relative"><canvas id="barChartFull"></canvas></div>
      </div>
    </div>
    <div class="page-title" style="margin-bottom:1rem;font-size:.95rem">📂 Pecahan Kategori</div>
    <div id="categoryCards" style="display:flex;flex-direction:column;gap:.6rem"></div>
  </div>

  <!-- ═══ CHATBOT ═══ -->
  <div class="page" id="page-chatbot">
    <div class="card" style="padding:0;overflow:hidden">
      <div style="padding:1rem 1.25rem;border-bottom:1px solid var(--card-border);display:flex;align-items:center;gap:.75rem">
        <div style="width:38px;height:38px;background:linear-gradient(135deg,var(--primary),var(--accent));border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.3rem">🤖</div>
        <div>
          <div style="font-weight:700;color:#fff">PocketBot AI</div>
          <div style="font-size:.75rem;color:var(--success);display:flex;align-items:center;gap:4px">
            <span style="width:7px;height:7px;background:var(--success);border-radius:50%;display:inline-block"></span> Online
          </div>
        </div>
      </div>
      <div class="chat-messages" id="chatMessages"></div>
      <div class="chat-suggestions">
        <button class="chat-suggestion" onclick="sendChat('Aku dah habis berapa bulan ni?')">Aku dah habis berapa bulan ni?</button>
        <button class="chat-suggestion" onclick="sendChat('Bajet aku cukup tak?')">Bajet aku cukup tak?</button>
        <button class="chat-suggestion" onclick="sendChat('Aku belanja paling banyak kat mana?')">Paling banyak belanja kat mana?</button>
        <button class="chat-suggestion" onclick="sendChat('Macam mana nak jimat duit?')">Macam mana nak jimat duit?</button>
      </div>
      <div class="chat-input-wrap">
        <textarea class="chat-input" id="chatInput" rows="1" placeholder="Tanya PocketBot apa-apa…"></textarea>
        <button class="chat-send" onclick="sendChat()">➤</button>
      </div>
    </div>
  </div>

  <!-- ═══ SETTINGS ═══ -->
  <div class="page" id="page-settings">
    <div class="page-title" style="margin-bottom:1.25rem">Tetapan <span>Akaun</span></div>
    <div class="card" style="max-width:480px;margin-bottom:1rem">
      <div class="chart-title">🎯 Bajet Bulanan</div>
      <p style="font-size:.82rem;color:var(--text-muted);margin-bottom:1rem">Tetapkan had perbelanjaan untuk bulan yang dipilih.</p>
      <div class="form-group">
        <label class="form-label">Jumlah Bajet (RM)</label>
        <input type="number" id="budgetInput" class="form-input" placeholder="cth: 1500" min="1" step="0.01">
      </div>
      <button class="btn-primary-custom" onclick="saveBudget()">💾 Simpan Bajet</button>
    </div>
    <div class="card" style="max-width:480px">
      <div class="chart-title">👤 Profil</div>
      <div style="display:flex;align-items:center;gap:1rem;padding:.5rem 0">
        <div style="width:56px;height:56px;background:linear-gradient(135deg,var(--primary),var(--accent));border-radius:14px;display:flex;align-items:center;justify-content:center;font-size:1.8rem"><?= $userAvatar ?></div>
        <div>
          <div style="font-weight:700;font-size:1rem;color:#fff"><?= $userName ?></div>
          <div style="font-size:.82rem;color:var(--text-muted)">Akaun Pelajar</div>
        </div>
      </div>
      <div style="margin-top:1rem;padding-top:1rem;border-top:1px solid var(--card-border)">
        <button class="btn-outline" onclick="location.href='auth.php?action=logout'" style="color:var(--danger);border-color:rgba(225,112,85,.4)">🚪 Log Keluar</button>
      </div>
    </div>
  </div>

</div><!-- /main-content -->

<!-- ═══ MODAL ═══ -->
<div class="modal-overlay" id="expenseModal">
  <div class="modal-box">
    <div class="modal-title" id="modalTitle">➕ Tambah Perbelanjaan</div>
    <div class="form-group">
      <label class="form-label">Tarikh *</label>
      <input type="date" id="expenseDate" class="form-input">
    </div>
    <div class="form-group">
      <label class="form-label">Kategori *</label>
      <select id="expenseCategory" class="form-select">
        <option value="">— Pilih kategori —</option>
        <?php foreach ($categories as $cat): ?>
          <option value="<?= $cat ?>"><?= $categoryIcons[$cat] ?> <?= $cat ?></option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group">
      <label class="form-label">Jumlah (RM) *</label>
      <input type="number" id="expenseAmount" class="form-input" placeholder="0.00" min="0.01" step="0.01">
    </div>
    <div class="form-group">
      <label class="form-label">Keterangan (pilihan)</label>
      <input type="text" id="expenseDesc" class="form-input" placeholder="cth: Makan tengah hari" maxlength="255">
    </div>
    <div style="display:flex;gap:.75rem;margin-top:1.25rem">
      <button class="btn-primary-custom" id="btnSaveExpense" style="flex:1">💾 Simpan</button>
      <button class="btn-outline" id="btnCancelModal">Batal</button>
    </div>
  </div>
</div>

<div class="toast-container" id="toastContainer"></div>

<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<script src="js/app.js"></script>
</body>
</html>
